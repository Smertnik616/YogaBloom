import "./js/modal.js"
import "./js/navbar.js"